<?php

$str .= '<h1 style="text-align:'.$nd_options_text_align.'; color:'.$nd_options_number_color.'; font-size:'.$nd_options_number_font_size.'px; " class=" nd_options_counter_component_l1 nd_options_font_weight_bolder nd_options_counter '.$nd_options_class.' " data-to="'.$nd_options_number.'" data-speed="1000">'.$nd_options_number.'</h1>';