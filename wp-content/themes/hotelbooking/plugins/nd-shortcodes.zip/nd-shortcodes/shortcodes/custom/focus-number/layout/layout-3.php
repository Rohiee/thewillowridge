<?php

  
$str .= '

  
    <!--START FOCUS NUMBER-->
  <div style="" class=" '.$nd_options_class.' nd_options_focusnumber_component_l3 nd_options_section nd_options_box_sizing_border_box">
    
    <div class="nd_options_float_left">
      <h1 style="color:'.$nd_options_text_color.';" class="nd_options_font_size_60 nd_options_font_weight_normal">'.$nd_options_number.'</h1>
    </div>

    <div class="nd_options_float_left nd_options_margin_left_20">
      <div class="nd_options_section nd_options_height_5"></div>
      <div class="nd_options_section nd_options_height_2"></div>
      <div class="nd_options_section nd_options_height_2"></div>
      <p class="nd_options_letter_spacing_2 nd_options_line_height_14" style="color:'.$nd_options_text_color.';">'.$nd_options_title.'</p>
      <div class="nd_options_section nd_options_height_10"></div>
      <p class="nd_options_letter_spacing_2 nd_options_line_height_14" style="color:'.$nd_options_text_color.';">'.$nd_options_description.'</p>
    </div> 

  </div>
  <!--END FOCUS NUMBER-->

   ';