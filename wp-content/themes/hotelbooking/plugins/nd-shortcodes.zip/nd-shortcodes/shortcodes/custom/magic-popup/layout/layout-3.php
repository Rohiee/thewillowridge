<?php


$str .= '

    <div class=" '.$nd_options_class.' nd_options_section nd_options_mpopup_gallery nd_options_bg_white nd_options_border_radius_5 nd_options_position_relative nd_options_fadein_fadeout nd_options_overflow_hidden">

        <div class="nd_options_section nd_options_overflow_hidden">
            <img class="nd_options_section nd_options_border_radius_5_5_0_0 nd_options_zoom_image" src="'.$nd_options_image_src[0].'">
        </div>


        <div class="nd_options_border_top_width_0 nd_options_border_bottom_width_0 nd_options_section nd_options_text_align_center nd_options_position_relative nd_options_border_4_solid_grey nd_options_box_sizing_border_box">
            <div style="background-color:'.$nd_options_bg_icon.';" class=" nd_options_margin_top_negative_28 nd_options_display_inline_block nd_options_height_56 nd_options_width_56 nd_options_border_radius_100_percentage nd_options_border_3_solid_white nd_options_box_sizing_border_box">
                <a class="nd_options_mpopup_gallery" href="'.$nd_options_image_src[0].'"><img class="nd_options_margin_top_15 nd_options_rotate" alt="" width="20" height="20" src="'.$nd_options_icon_src[0].'"></a>
            </div> 
        </div>


        <div class="nd_options_section nd_options_padding_0_20 nd_options_box_sizing_border_box nd_options_border_4_solid_grey nd_options_text_align_center nd_options_border_top_width_0 nd_options_border_radius_0_0_5_5">
            <div class="nd_options_section nd_options_height_10"></div>
            <h3>'.$nd_options_title.'</h3>
            <p>'.$nd_options_description.'</p>
            <div class="nd_options_section nd_options_height_20"></div>
        </div>

    </div>

   ';