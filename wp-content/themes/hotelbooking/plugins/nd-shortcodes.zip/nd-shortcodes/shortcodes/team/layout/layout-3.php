<?php

  
$str .= '

  <!--START team-->
  <div style="background-color:'.$nd_options_color.';" class="nd_options_section '.$nd_options_class.'">

      <div class="nd_options_float_left nd_options_width_40_percentage nd_options_width_100_percentage_responsive">
          <img alt="" class="nd_options_section" src="'.$nd_options_image_src[0].'">
      </div>
      
      <div class="nd_options_float_left nd_options_width_60_percentage nd_options_width_100_percentage_responsive">
          <div class="nd_options_section nd_options_padding_20 nd_options_box_sizing_border_box">
          
              <h4 class="nd_options_color_white">'.$nd_options_title.'</h4>                        
              <div class="nd_options_section nd_options_height_20"></div>
              <div class="nd_options_section nd_options_line_height_0"><span class="nd_options_height_2 nd_options_width_30 nd_options_display_inline_block nd_options_bg_white"></span></div>
              <div class="nd_options_section nd_options_height_20"></div>
              <p class="nd_options_color_white">'.$nd_options_description.'</p>
              <div class="nd_options_section nd_options_height_20"></div>
              <a rel="'.$nd_options_link_rel.'" target="'.$nd_options_link_target.'" class="nd_options_margin_0_important nd_options_border_1_solid_white nd_options_display_inline_block nd_options_color_white nd_options_first_font nd_options_padding_8  nd_options_font_size_15" href="'.$nd_options_link_url.'">'.$nd_options_link_title.'</a>

          </div>
      </div>

  </div>
  <!--END team-->

';