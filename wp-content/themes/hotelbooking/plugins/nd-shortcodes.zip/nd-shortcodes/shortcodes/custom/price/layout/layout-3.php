<?php

  
$str .= '


  <!--START PRICE-->
  <div class="nd_options_section nd_options_border_1_solid_grey '.$nd_options_class.' ">

      <div style="background-color:'.$nd_options_color.';" class="nd_options_float_left nd_options_text_align_center nd_options_width_50_percentage nd_options_width_100_percentage_responsive">
          <div class="nd_options_section nd_options_position_relative nd_options_overflow_hidden nd_options_padding_25 nd_options_box_sizing_border_box">

                <img class="nd_options_position_absolute nd_options_bottom_20 nd_options_left_20_negative" width="70" src="'.$nd_options_image_src[0].'">
          
              <div class="nd_options_section nd_options_height_30"></div>
          
              <h1 class="nd_options_color_white nd_options_second_font">'.$nd_options_price.'</h1>
              <div class="nd_options_section nd_options_height_20"></div>
              <div class="nd_options_section nd_options_line_height_0"><span class="nd_options_height_2 nd_options_width_30 nd_options_display_inline_block nd_options_bg_white"></span></div>
              <div class="nd_options_section nd_options_height_20"></div>
              <h4 class="nd_options_color_white nd_options_second_font">'.$nd_options_sub_title.'</h4>

              <div class="nd_options_section nd_options_height_30"></div>                      
      
          </div>

      </div>
      
      <div class="nd_options_float_left nd_options_width_50_percentage nd_options_width_100_percentage_responsive">
          <div class="nd_options_section nd_options_padding_35 nd_options_box_sizing_border_box">
          
              <h4>'.$nd_options_title.'</h4>                        
              <div class="nd_options_section nd_options_height_20"></div>
              <p>'.$nd_options_description_2.'</p>

          </div>
      </div>


    </div>
  <!--END PRICE-->


   ';