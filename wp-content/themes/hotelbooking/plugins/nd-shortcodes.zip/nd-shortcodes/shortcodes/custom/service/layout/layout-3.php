<?php

  
$str .= '

    <div class="nd_options_section nd_options_position_relative '.$nd_options_class.'">
        <a rel="'.$nd_options_link_rel.'" '.$nd_options_link_target_output.' href="'.$nd_options_link_url.'"><img alt="" class="" width="50" src="'.$nd_options_image_src[0].'"></a>
        <div class="nicdark_section nicdark_height_20"></div>
        <a rel="'.$nd_options_link_rel.'" '.$nd_options_link_target_output.' href="'.$nd_options_link_url.'"><h2 style="color:'.$nd_options_title_color.';"><strong>'.$nd_options_title.'</strong></h2></a>
        <div class="nicdark_section nicdark_height_20"></div>
        <p style="color:'.$nd_options_description_color.';" class="">'.$nd_options_description.'</p>
        <div class="nicdark_section nicdark_height_20"></div>
        <a style="background-color:'.$nd_options_button_bg.'; color:'.$nd_options_button_text_color.'; border: 1px solid '.$nd_options_button_border_color.'; " rel="'.$nd_options_link_rel.'" '.$nd_options_link_target_output.' href="'.$nd_options_link_url.'" class="nd_options_display_inline_block  nd_options_first_font  nd_options_padding_8 nd_options_border_radius_3 nd_options_font_size_13">'.$nd_options_link_title.'</a>
    </div>


  ';
