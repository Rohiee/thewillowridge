<?php

  
$str .= '

  <!--START TESTIMONIAL-->
  <div class="nd_options_section '.$nd_options_class.'">
                                            
    <div style="background-color:'.$nd_options_color.';" class="nd_options_section nd_options_padding_20 nd_options_box_sizing_border_box">
      <p class="nd_options_color_white nd_options_margin_0_important">'.$nd_options_testimonial.'</p>
    </div> 
    <div class="nd_options_section ">
      <div style="border-top-color:'.$nd_options_color.';" class="nd_options_margin_left_20 nd_options_height_0 nd_options_width_0 nd_options_border_style_solid nd_options_border_color_transparent nd_options_border_width_15 nd_options_border_bottom_width_0"></div> 
    </div>
    <div class="nd_options_section nd_options_height_20 "></div>

    <div class="nd_options_section  nd_options_position_relative">

      <img alt="" width="70" height="70" class="nd_options_position_absolute nd_options_border_radius_100_percentage nd_options_top_0 nd_options_left_0" src="'.$nd_options_image_src[0].'">
      
      <div class="nd_options_section nd_options_padding_left_90 nd_options_min_height_70 nd_options_box_sizing_border_box">
        <div class="nd_options_section nd_options_height_10 "></div>
        <h4 class="nd_options_margin_0_important nd_options_font_weight_normal">'.$nd_options_name.'</h4>
        <div class="nd_options_section nd_options_height_10 "></div>
        <p class="nd_options_margin_0_important">'.$nd_options_role.'</p>
      </div>

    </div> 


  </div>
  <!--END TESTIMONIAL-->

   ';