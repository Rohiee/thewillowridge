<?php

  
$str .= '


    <div class="nd_options_section nd_options_position_relative '.$nd_options_class.'">
        <a rel="'.$nd_options_link_rel.'" '.$nd_options_link_target_output.' href="'.$nd_options_link_url.'"><img alt="" class="nd_options_position_absolute nd_options_left_0" width="40" src="'.$nd_options_image_src[0].'"></a>
        <div class="nd_options_section nd_options_padding_left_70 nd_options_box_sizing_border_box">
            <a rel="'.$nd_options_link_rel.'" '.$nd_options_link_target_output.' href="'.$nd_options_link_url.'"><h3 style="color:'.$nd_options_title_color.';"><strong>'.$nd_options_title.'</strong></h3></a>
            <div class="nd_options_section nd_options_height_15"></div>
            <p style="color:'.$nd_options_description_color.';" class="">'.$nd_options_description.'</p>
        </div>
    </div>


  ';
