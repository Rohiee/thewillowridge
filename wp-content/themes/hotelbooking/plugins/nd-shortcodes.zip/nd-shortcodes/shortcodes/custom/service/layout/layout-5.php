<?php

  
$str .= '


    <div class="nd_options_section nd_options_position_relative '.$nd_options_class.'">
        <img alt="" class="nd_options_position_absolute nd_options_left_0" width="55" src="'.$nd_options_image_src[0].'">
        <div class="nd_options_section nd_options_padding_left_80 nd_options_box_sizing_border_box">
            <h1 class="nd_options_font_size_40 nd_options_line_height_50" style="color:'.$nd_options_title_color.';"><strong>'.$nd_options_title.'</strong></h1>
        </div>
    </div>


  ';
