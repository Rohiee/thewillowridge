<?php


$str .= '

    <div class=" '.$nd_options_class.' nd_options_section nd_options_text_align_center ">

        <a style="background-color:'.$nd_options_bg_link.';" class=" nd_options_mpopup_iframe nd_options_border_radius_3 nd_options_color_white nd_options_outline_0 nd_options_padding_10_20" href="'.$nd_options_link_url.'">'.$nd_options_link_title.'</a>
       
   </div>
   ';